package week5.day1;

import org.testng.annotations.Test;

public class Sample {
	@Test
	public static void main(String[] args) {
	
	System.out.println("running");

	}


}
