package week5.day1;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class LearnAtTest {
	@BeforeMethod
	public void getintoODC() {
		System.out.println("Get into ODC");
	}
	/*@Test
	public void actualTask() {
		System.out.println("Actual Work");
	}*/
	@Test
	public void takebreak() {
		System.out.println("Lunch Break");
	}
	/*@AfterMethod
	public void getOutOfODC() {
		System.out.println("Get out of ODC");
	}*/
	
	/*@Test
	public void bparkVechicle() {
		System.out.println("Park the bike");
	}
	@Test
	public void ctakeStairs() {
		System.out.println("Take the stairs");
		
	}
	@Test
	public void agetIntoClass() {
		System.out.println("Get into class room");
	}
	
*/	
	
	
	
	
	
	
	
	

}
