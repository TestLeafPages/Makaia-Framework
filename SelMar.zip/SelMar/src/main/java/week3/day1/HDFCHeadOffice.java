package week3.day1;

public abstract class HDFCHeadOffice implements RBI, CIBIL{

	public void linkAadhar() {
		System.out.println("aadhar linked ");
	}

	public void getCreditScore() {
		System.out.println("get Credit Score");
	}
	
}
