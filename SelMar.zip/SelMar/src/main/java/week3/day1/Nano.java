package week3.day1;

public class Nano extends Car{
	public void soundSystem()
	{
		System.out.println("Sound system available");
	}

}
