package week3.day1;

public abstract class LearnAbstract {

	public String username ;
	
	public abstract void displayUsername();
	
	private void displayUser() {
		
	}
}
