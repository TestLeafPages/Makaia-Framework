package week3.day1;

public interface LearnInterface {

	 String username = "";
	 
	 public void getUsername();
	
}
