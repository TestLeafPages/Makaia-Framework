package week3.day1;

public class HDFCCBE extends HDFCHeadOffice{

	@Override
	public void setMinBalance() {
		System.out.println("Minimum balance 3000");
	}  

	
}
