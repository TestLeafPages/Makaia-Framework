package week3.day1;

public class Car extends Vechicle{
	
	public void acclerate()
	{
		System.out.println("The car will move faster");
	} 
	
	public static void main(String[] args) {
		Audi objcar= new Audi();
		objcar.brake();
		Nano objNano=new Nano();
		//objNano.acclerate();
		objcar.airBag();
		//Car vechicle = new Car();
		
		//LearnInterface li = new LearnInterface();
		//LearnAbstract la = new LearnAbstract();
		
		
		
		
		
		
		
		
		
		
		
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
