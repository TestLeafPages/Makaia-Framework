package week3.day1;

public class HDFCChennai extends HDFCHeadOffice{
	
	@Override
	public void setMinBalance() {
		System.out.println("Minimum balance is 5000");
	}


}
