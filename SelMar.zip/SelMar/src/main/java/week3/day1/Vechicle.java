package week3.day1;

public class Vechicle {

	public String username ;
	public void brake()
	{ 
		System.out.println("The car will stop");
	}
}
