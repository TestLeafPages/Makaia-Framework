package week3.day1;

public interface CIBIL {

	public void getCreditScore();
}
