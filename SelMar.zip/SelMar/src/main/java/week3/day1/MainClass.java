package week3.day1;

public class MainClass {

	public static void main(String[] args) {
		HDFCChennai hdfc = new HDFCChennai();
		hdfc.linkAadhar();
		hdfc.setMinBalance();
		
		HDFCCBE cbe = new HDFCCBE();
		cbe.linkAadhar();
		cbe.setMinBalance();
		

	}

}
