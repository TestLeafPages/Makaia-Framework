package week3.day2;

public class LearnFinal {

	final static int i =10;
	
	public static void main(String[] args) {
		//i =20;
		System.out.println(i); 
	}
}
