package week3.day2;

import java.util.ArrayList;
import java.util.List;

public class LearnList {

	public static void main(String[] args) {
		
		/*String[] obj = new String[5];
		obj[0]="10";
		obj[1]="5";
		obj[2]=10;*/
		
		List<String> mentors= new ArrayList<>();
		mentors.add("Balaji");
		mentors.add("Gayatri");
		mentors.add("Koushik");
		mentors.add("Sarath");
		mentors.add("Mohan");
		
		}
		
//		System.out.println(mentors.get(1));
		
		/*for (String eachmentor : mentors) {
			System.out.println(eachmentor);
			
		}
		System.out.println(mentors.size());*/
		//mentors.add("Balaji");
		/*for (String eachmentor : mentors) {
			System.out.println(eachmentor);
			
		}
		System.out.println(mentors.size());*/
		/*mentors.remove("Gayatri");
		System.out.println(mentors.contains("Gayatri"));
		
		
		mentors.clear();
		
		System.out.println(mentors.isEmpty());*/
		

		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	

}
