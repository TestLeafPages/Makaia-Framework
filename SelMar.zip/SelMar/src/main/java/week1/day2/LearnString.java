package week1.day2;

public class LearnString {
	public static void main(String[] args) {
		Integer i =10;
		//System.out.println(i.toString()+10);  

		char ch = 'A';
		System.out.println((char)(ch+32));  
		/*String companyName = "TestLeaf"; 
		char[] eachChar =companyName.toCharArray();
		for (char c : eachChar) {
			System.out.println(c); 
		}*/
		
		/*System.out.println(companyName);
		System.out.println(companyName.trim());*/
		
		
		/*
		String cityName = "Chennai,Bangalore,Pune,Ap";
		String[] cities = cityName.split(" ");
		for(String eachCity : cities) 
			System.out.println(eachCity.toUpperCase());*/ 
		
		
		
		
		
		
		
		
		//System.out.println("Chennai ".concat(companyName));
		//System.out.println(companyName.replace("e", "E"));
		//System.out.println(companyName.concat(" Chennai"));
		//System.out.println(companyName.substring(4));  
		//System.out.println(companyName.lastIndexOf('e'));
		//System.out.println(companyName.contains("e"));
		//System.out.println(companyName.charAt(0));
		//System.out.println(companyName.endsWith("TestLeaf"));
		
		
		
		
		
		
		
		
		
		/*//String companyName1 = new String("TestLeaf");
		//int length = companyName.length();
		System.out.println(companyName.length());*/ 
		

	}

}


