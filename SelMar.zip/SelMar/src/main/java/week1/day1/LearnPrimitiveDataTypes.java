package week1.day1;

public class LearnPrimitiveDataTypes {

	public static void main(String[] args) {
		
		int age = 15;
		if(age>=60) {
			System.out.println("senior");  
		} else if(age >= 18) {
			System.out.println("adult");
		} else {
			System.out.println("not an adult");  
		}
		
		
		
		
		
		
		
		
		
		
		
		/*int num1 = 10;
		int num2 =  10; 
		boolean answer = (num1>15) || (num2>15);
		System.out.println(answer);*/ 
		
		
		
		
		
		
		
		
		
		//int answer = num1%num2;
		//num1++; // num1 = num1+1;
		/*System.out.println(num1++);
		System.out.println(++num1);*/ 
		
		
		
		
		
		
		
		/*char ch = 'K';
		double area = 923.46;
		System.out.println("area value = "+area+ch); */
	}
}
