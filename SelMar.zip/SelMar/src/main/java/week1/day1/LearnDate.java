package week1.day1;

import java.util.Calendar;
import java.util.Date;

public class LearnDate {
	public static void main(String[] args) {
		Date dat = new Date();
		Calendar cl = null;
		Calendar instance = Calendar.getInstance();
		System.out.println(instance);
		
		
	}

}
